import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from '../login/login/login.component';
import { RegistrationComponent } from '../registration/registration/registration.component';
import { HomeComponent } from '../home/home/home.component';
import {Routes,RoouterModule} from '@angular/router';


const routes:Routes=[{path:'login',component:LoginComponent},
{path:'register',component:RegistrationComponent},
{path:'home',component:HomeComponent}]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RoouterModule
  ]
})
export class RoutingModule { }
