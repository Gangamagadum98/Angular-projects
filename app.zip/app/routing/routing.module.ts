import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from '../login/login/login.component';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from '../registration/registration/registration.component';
import { HomeComponent } from '../home/home/home.component';
import { ProductsComponent } from '../home/products/products.component';
import { MenuComponent } from '../home/menu/menu.component';
import { CartComponent } from '../home/cart/cart.component';
import { PaymentComponent } from '../home/payment/payment.component';


const routes:Routes=[{path:'login',component:LoginComponent},
{path:'registration',component:RegistrationComponent},
{path:'home',component:HomeComponent,
children:[{path:'products',component:ProductsComponent},
{path:'menu',component:MenuComponent},
{path:'cart',component:CartComponent},
{path:'payment',component:PaymentComponent},
{path:'**',redirectTo:'products'}]},
{path:'**',redirectTo:'login'}]



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule]
})
export class RoutingModule { }

