export function customvalidation(formGroup){

    let password=formGroup.value.pass
    let confirmPassword = formGroup.value.cpass
    console.log(password, confirmPassword)
    return password == confirmPassword?null:{'custom':true}
        
    
}