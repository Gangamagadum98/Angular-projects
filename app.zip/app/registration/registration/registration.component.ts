import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { customvalidation } from '../CustomValidation';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {


  fields={
    fname:["",[Validators.required, Validators.minLength(3)]],
    lname:["",[Validators.required]],
    mail:["",[Validators.required]],
    pass:["",[Validators.required]],
    cpass:["",[Validators.required]],
    phno:["",[Validators.required, Validators.minLength(10), Validators.maxLength(10)]],

  }

  constructor(private _builder:FormBuilder, private _router:Router) { }

  
  form = this._builder.group(this.fields,{validators:customvalidation})

  ngOnInit() {
   
}
register(){
  console.log(this.form.value)
  
  let userObj = JSON.stringify(this.form.value)
  localStorage.setItem(this.form.get('mail').value, userObj)
  this._router.navigate(["login"])

}


}
