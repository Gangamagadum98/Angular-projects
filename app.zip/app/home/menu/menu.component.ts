import { Component, OnInit } from '@angular/core';
import { ProductService } from '../products/product.service';
import { CartService } from '../cart/cart.service';
import { isNgTemplate } from '@angular/compiler';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  starters:[]
  main:[]
  beverages:[]

  constructor(private _service:ProductService, private _cart:CartService) { }

  addToCart(product){
    let index = this._cart.cartItems.findIndex(
      item => item.name==product.name)
      if(index!=-1){
        this._cart.cartItems[index].qty++
      }
      else{
        product.qty=1
        this._cart.cartItems.push(product)
      }
  }

  


  ngOnInit() {
    this._service.getMenuDetails().subscribe((data)=>{
      let menu = data["menu"]
      this.starters = menu[0].starter
      this.main = menu[1].main
      this.beverages = menu[2].Beverages
      console.log(data["menu"])
    },
    (err)=>{
      console.log(err)
    })
  }

}
