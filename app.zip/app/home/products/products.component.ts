import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  restaurants:[]

  constructor(private _service:ProductService, private _router:Router) { }

  navigateToMenu(){
    this._router.navigate(["home/menu"])
  }

  ngOnInit() {

    this._service.getProducts().subscribe((data)=>{
      this.restaurants=data['restaurants']
      console.log(data)
    },
    (err)=>{
      console.log(err)
    })
  }

}
