import { Component, OnInit } from '@angular/core';
import { CartService } from './cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  items = []
  total=0

  constructor(private _service:CartService, private _router:Router) { }

  calculateTotal(){
    this.total=this._service.cartItems.reduce((acc,item)=>acc+(item.price*item.qty),0)

  }
  remove(item){
    this._service.cartItems.splice(this._service.cartItems.indexOf(item,1))
    this.calculateTotal()
  }
  increment(product){
    product.qty++
    this.calculateTotal()
  }
  decrement(product){
    if(product.qty == 1){
     this.remove(product)
    }
    else{
      product.qty--
      this.calculateTotal()
    }
  }

  navigateToPayment(){
    this._router.navigate(["home/payment"])
  }

  ngOnInit() {
    this.items=this._service.cartItems
    this.calculateTotal()
  }

}
