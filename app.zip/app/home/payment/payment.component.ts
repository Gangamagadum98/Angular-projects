import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  captch
  captchValue=""
  showError

  constructor() { }

  alphabate=["a","Z","c","T","e","S","A","W","O","d"]

  generateCaptch(){
    let captch=""
    for(let i=0;i<7;i++){
      if(i==2||i==4||i==6){
        captch+=this.alphabate[Math.floor(Math.random()*10)]
      }
      else{
        captch+=Math.floor(Math.random()*10)
      }
    }
    return captch
   

  }
  refresh(){
    this.captch=this.generateCaptch()
  }
  pay(){
    if(this.captchValue == this.captch){
      this.showError=false
      alert("payment success")
      
    }
    else{
      this.showError=true
      this.refresh()
    }
  }

  ngOnInit() {
    this.generateCaptch()
   
  }

}
