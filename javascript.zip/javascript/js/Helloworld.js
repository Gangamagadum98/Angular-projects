let name='john'

let score = 100
let bonus = 20
let totalScore = score + bonus
console.log(totalScore)

let firstName = 'john'
let lastName= 'Doe'
console.log(firstName+' '+lastName)